
module.exports = function(app){

    app.post('/api', function(req, res){
        app.app.controllers.api(app, req, res);
    });
};