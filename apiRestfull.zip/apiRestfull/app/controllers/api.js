module.exports.api = function(app, req, res){

    var dados = req.body;
    res.send(dados);
    return;

};
